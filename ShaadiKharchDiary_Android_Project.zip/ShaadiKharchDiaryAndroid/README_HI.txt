शादी खर्च डायरी - Android Studio प्रोजेक्ट

यह Android WebView ऐप प्रोजेक्ट है। इसमें आपकी EMI वाली डायरी assets/index.html में रखी गई है।

APK बनाने के लिए:
1. Android Studio में इस पूरे फोल्डर को Open करें।
2. Gradle Sync पूरा होने दें।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

ध्यान दें:
- इस पैकेज में तैयार APK नहीं, Android Studio source project है।
- इस वातावरण में Android SDK/Gradle build उपलब्ध न होने के कारण APK compile नहीं किया जा सका।
- डेटा फोन के ऐप के WebView storage में रहता है। ऐप डेटा साफ करने या uninstall करने से पहले डायरी का Backup डाउनलोड करें।
- EMI के लिए अभी ऐप खुलने पर due reminder दिखता है; ऐप बंद रहने पर native scheduled notification इस starter project में शामिल नहीं है।
